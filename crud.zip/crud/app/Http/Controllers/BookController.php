<?php

namespace App\Http\Controllers;

use Mail;
use App\Book;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $books = Book::latest()->paginate(5);
  
        return view('books.index',compact('books'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('books.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
        ]);
  
        Book::create($request->all());

       
             # Send email whenever record is created, currently I have commented the block because I can't email without SMTP setting
             # You can define your smpt settings and uncomment this block of email sending
             /*Mail::send([], [], function ($message) {
                $message->to('yuradragan@gmail.com');
                $message->from('ahmed.omair@gmail.com','Omair Khan');
                $message->subject('New Book Record Created');
                $message->setBody('Hi, New Book Record Created!');
    
              });*/
        
   
        return redirect()->route('books.index')
                        ->with('success','Book created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function show(Book $book)
    {
        return view('books.show',compact('book'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(Book $book)
    {
        return view('books.edit',compact('book'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Book $book)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
        ]);
  
        $book->update($request->all());

        if ($book) {

             # Send email whenever record is created, currently I have commented the block because I can't email without SMTP setting
             # You can define your smpt settings and uncomment this block of email sending
             
            /*Mail::send([], [], function ($message) {
                $message->to('yuradragan@gmail.com');
                $message->from('ahmed.omair@gmail.com','Omair Khan');
                $message->subject('Book Record Updated');
                $message->setBody('Hi, Existing Book Record Updated!');
    
              });*/
        }
  
        return redirect()->route('books.index')
                        ->with('success','Book updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(Book $book)
    {
        $book->delete();
  
        return redirect()->route('books.index')
                        ->with('success','Book deleted successfully');
    }
}
